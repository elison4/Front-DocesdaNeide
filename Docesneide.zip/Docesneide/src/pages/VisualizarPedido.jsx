import Navbar from "../components/Navbar";
import "./VisualizarPedido.css";

export default function VisualizarPedido() {
  return (
    <>
      <Navbar />

      <div className="pedido-container">
        <h1>
          Pedido <span className="pedido-id">#16424</span>
        </h1>

        <div className="pedido-card">
          <div className="pedido-info">
            <p><strong>Data do pedido:</strong> 13/08/2025</p>
            <p><strong>Dados do cliente:</strong> Dona Maria</p>
            <p><strong>Entrega em:</strong> Rua das dores, 195</p>

            <div className="entrega-detalhes">
              <p>Dia da entrega: 14/08/2025</p>
              <p>Horário da entrega: 14:30</p>
              <p>Entregar no nome de: Maria</p>
            </div>
          </div>

          <div className="pedido-produtos">
            <ul>
              <li>10 brigadeiros</li>
              <li>5 alfajores</li>
            </ul>
          </div>

          <div className="pedido-buttons">
            <button className="btn-rosa">Novo pedido</button>
            <button className="btn-rosa">Página inicial</button>
          </div>
        </div>
      </div>
    </>
  );
}
