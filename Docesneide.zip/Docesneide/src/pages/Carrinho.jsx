import { useState } from "react";
import Navbar from "../components/Navbar";
import "./Carrinho.css";

export default function Carrinho() {
  // Exemplo de produtos (Algum dia tu vai fazer no backend)
  const [itens, setItens] = useState([
    { id: 1, nome: "Cupcake", preco: 2.5, quantidade: 1 },
    { id: 2, nome: "Cupcake", preco: 2.5, quantidade: 1 },
    { id: 3, nome: "Cupcake", preco: 2.5, quantidade: 1 },
  ]);

  // Atualiza a quantidade
  const alterarQuantidade = (id, delta) => {
    setItens((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              quantidade: Math.max(1, item.quantidade + delta), // nunca menor que 1
            }
          : item
      )
    );
  };

  // Remove um item
  const removerItem = (id) => {
    setItens((prev) => prev.filter((item) => item.id !== id));
  };

  // Calcula total da compra
  const total = itens.reduce(
    (acc, item) => acc + item.preco * item.quantidade,
    0
  );

  return (
    <>
      <Navbar />
      <div className="carrinho-container">
        <h1 className="carrinho-title">Cestinha de doces</h1>

        <div className="carrinho-grid">
          {itens.map((item) => (
            <div key={item.id} className="carrinho-item">
              <div className="carrinho-img" />
              <p className="carrinho-nome">{item.nome}</p>

              <div className="carrinho-quantidade">
                <button onClick={() => alterarQuantidade(item.id, -1)}>-</button>
                <span>{item.quantidade}</span>
                <button onClick={() => alterarQuantidade(item.id, 1)}>+</button>
              </div>

              <p className="carrinho-preco">
                Total: R${(item.preco * item.quantidade).toFixed(2)}
              </p>

              <button
                className="btn-remover"
                onClick={() => removerItem(item.id)}
              >
                Remover
              </button>
            </div>
          ))}
        </div>

        <div className="carrinho-footer">
          <h2>
            Total da compra: <span>R${total.toFixed(2)}</span>
          </h2>
          <button className="btn-finalizar">Finalizar pedido</button>
        </div>
      </div>
    </>
  );
}
