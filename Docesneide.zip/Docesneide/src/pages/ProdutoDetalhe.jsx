import "./ProdutoDetalhe.css";
import Navbar from "../components/Navbar";

export default function ProdutoDetalhe() {
  // depois da pra buscar esse produto via props, useParams ou API
  const produto = {
    nome: "Cupcake",
    categoria: "Bolos",
    descricao: "Cupcakes feitos com chocolate nobre e cobertura de morango do amor.",
    preco: 7.5,
    imagem: "https://via.placeholder.com/600x300", // exemplo
  };

  const adicionarAoCarrinho = () => {
    alert(`${produto.nome} foi adicionado ao carrinho!`);
    // aqui tu conecta com o JSON Server ou Context API
  };

  return (
    <>
      <Navbar />
    <div className="produto-detalhe-container">
      <h1 className="produto-nome">{produto.nome}</h1>

      <div className="produto-conteudo">
        <img
          src={produto.imagem}
          alt={produto.nome}
          className="produto-imagem"
        />

        <div className="produto-info">
          <h3>{produto.nome}</h3>
          <span className="produto-categoria">{produto.categoria}</span>
          <p className="produto-descricao">{produto.descricao}</p>

          <p className="produto-preco">
            Valor: <span>R${produto.preco.toFixed(2)}</span>
          </p>

          <button className="btn-carrinho" onClick={adicionarAoCarrinho}>
            Adicionar ao carrinho
          </button>
        </div>
      </div>
    </div>
    </>
  );
}
