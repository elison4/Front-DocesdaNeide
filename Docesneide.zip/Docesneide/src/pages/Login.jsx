import React from "react";
import Navbar from "../components/Navbar";
import "./Login.css";

function Login() {
  return (
    <>
      <Navbar />

    <div className="login-container">
      {/* Lado esquerdo - Formulário */}
      <div className="login-box">
        <h1>Entrar</h1>
        <p>Digite seus dados para encomendar seu produto.</p>

        <form>
          <input type="text" placeholder="Login" />
          <input type="password" placeholder="Senha" />
          <button type="submit">Acessar</button>
        </form>
      </div>

      {/* Lado direito - Cadastro */}
      <div className="register-box">
        <h2>Não possui cadastro?</h2>
        <p>
          É fácil, demora poucos minutinhos.
          <br />
          <a href="/cadastro">Clique aqui</a> para realizar seu cadastro.
        </p>
      </div>
    </div>
    </>
  );
}

export default Login;
