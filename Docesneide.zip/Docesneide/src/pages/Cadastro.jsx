import { useState } from "react";
import Navbar from "../components/Navbar";
import "./Cadastro.css";

export default function Cadastro() {
  const [formData, setFormData] = useState({
    login: "",
    email: "",
    senha: "",
    confirmarSenha: "",
    telefone: "",
    cep: "",
    endereco: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Dados enviados:", formData);
    // Aqui da pra tu integrar com o backend / JSON Server
  };

  return (
    <>
      <Navbar />

    <div className="cadastro-container">
      <div className="cadastro-box">
        <h1 className="cadastro-title">Cadastro</h1>
        <p className="cadastro-subtitle">
          Digite seus dados para criar sua conta.
        </p>

        <form onSubmit={handleSubmit} className="cadastro-form">
          <input
            type="text"
            name="login"
            placeholder="Login"
            value={formData.login}
            onChange={handleChange}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <input
            type="password"
            name="senha"
            placeholder="Senha"
            value={formData.senha}
            onChange={handleChange}
            required
          />

          <input
            type="password"
            name="confirmarSenha"
            placeholder="Confirmar senha"
            value={formData.confirmarSenha}
            onChange={handleChange}
            required
          />

          <input
            type="text"
            name="telefone"
            placeholder="Telefone"
            value={formData.telefone}
            onChange={handleChange}
            required
          />

          <input
            type="text"
            name="cep"
            placeholder="CEP"
            value={formData.cep}
            onChange={handleChange}
            required
          />

          <textarea
            name="endereco"
            placeholder="Endereço"
            value={formData.endereco}
            onChange={handleChange}
            rows="3"
          />

          <button type="submit" className="btn-cadastro">
            Criar conta
          </button>
        </form>
      </div>
    </div>
    </>
  );
}
