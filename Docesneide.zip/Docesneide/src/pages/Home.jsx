import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import Navbar from "../components/Navbar";
import "./Home.css";

export default function Home() {
  const [categoria, setCategoria] = useState("");
  const location = useLocation();

  // Detecta hash na URL e rola suavemente até a seção
  useEffect(() => {
    if (location.hash) {
      const target = document.querySelector(location.hash);
      if (target) {
        // Pequeno delay para garantir que a renderização ocorreu
        setTimeout(() => {
          target.scrollIntoView({ behavior: "smooth" });
        }, 100);
      }
    }
  }, [location]);

  const doces = [
    { id: 1, nome: "Brigadeiro", categoria: "Docinho", preco: 2.5 },
    { id: 2, nome: "Torta de morango", categoria: "Bolos", preco: 2.5 },
    { id: 3, nome: "Cupcake", categoria: "Bolos", preco: 2.5 },
  ];

  const promocoes = [
    { id: 4, nome: "Caixinha especial Dia dos Pais", preco: 22.5, tag: "Dia dos Pais" },
    { id: 5, nome: "Ovo de Colher", preco: 87.5, tag: "Páscoa" },
    { id: 6, nome: "Brigadeiros", preco: 87.5, tag: "Leve 4 pague 3" },
  ];

  const eventos = [
    {
      id: 1,
      data: "22/08/2025",
      nome: "Congresso - Joinville",
      local: "Centro de Eventos",
      desc: "Docinhos e brigadeiros disponíveis. Demais doces sob encomenda."
    },
    {
      id: 2,
      data: "23/10/2025",
      nome: "Palestra - Balneario",
      local: "Palace Real",
      desc: "Docinhos e brigadeiros disponíveis. Demais doces sob encomenda."
    },
  ];

  return (
    <>
      <Navbar />

      {/* BANNER */}
      <section className="banner">
        <h2>Doces artesanais feitos sob encomenda.</h2>
        <div className="banner-buttons">
          <a href="#doces" className="btn-pink">Ver cardápio</a>
          <a href="#eventos" className="btn-gray">Próximos Eventos</a>
        </div>
      </section>

      {/* DOCES */}
      <section id="doces" className="section">
        <h2>Doces</h2>
        <div className="filters">
          <input type="text" placeholder="Pesquisar..." />
          <select value={categoria} onChange={(e) => setCategoria(e.target.value)}>
            <option value="">Selecionar categoria...</option>
            <option value="Docinho">Docinhos</option>
            <option value="Bolos">Bolos</option>
          </select>
        </div>

        <div className="grid">
          {doces.map((doce) => (
            <div key={doce.id} className="card">
              <div className="image"></div>
              <p className="nome">{doce.nome}</p>
              <span className="tag">{doce.categoria}</span>
              <p className="preco">R$ {doce.preco.toFixed(2)}</p>
              <button className="btn-pink">Ver produto</button>
              <span className="favorite">♡</span>
            </div>
          ))}
        </div>
      </section>

      {/* PROMOÇÕES */}
      <section id="promocoes" className="section">
        <h2>Promoções</h2>
        <p>Para tornar sua data comemorativa ainda mais especial.</p>
        <div className="grid">
          {promocoes.map((item) => (
            <div key={item.id} className="card">
              <div className="image"></div>
              <p className="nome">{item.nome}</p>
              <span className="tag">{item.tag}</span>
              <p className="preco">R$ {item.preco.toFixed(2)}</p>
              <button className="btn-pink">Ver produto</button>
              <span className="favorite">♡</span>
            </div>
          ))}
        </div>
      </section>

      {/* EVENTOS */}
      <section id="eventos" className="section">
        <h2>Eventos</h2>
        <p>Encontre o evento mais próximo de você para experimentar nossos doces!</p>
        <div className="grid grid-2">
          {eventos.map((evento) =>
            Array(1).fill(1).map((_, i) => (
              <div key={`${evento.id}-${i}`} className="evento-card">
                <p className="data">{evento.data}</p>
                <h3>{evento.nome}</h3>
                <p>{evento.local}</p>
                <p className="desc">{evento.desc}</p>
              </div>
            ))
          )}
        </div>
      </section>

      {/* CHAMADA ENTREGA */}
      <section id="encomendar" className="call">
        <p>Reside em Tubarão?</p>
        <button className="btn-pink">Faça seu pedido</button>
        <p className="sub">E levamos até você!</p>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <h2>Extras</h2>
        <ul>
          <li>Perguntas frequentes</li>
          <li>Faça uma pergunta</li>
          <li>Acompanhe nosso Instagram</li>
        </ul>
      </footer>
    </>
  );
}
