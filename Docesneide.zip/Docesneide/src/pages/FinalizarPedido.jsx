import Navbar from "../components/Navbar"; 
import "./FinalizarPedido.css";

export default function FinalizarPedido() {
  return (
    <>
      <Navbar />

      <div className="finalizar-pedido">
        <div className="form-section">
          <h1>Finalizar pedido</h1>
          <p>Digite seus dados para encomendar seu produto.</p>

          <form>
            <input type="text" placeholder="Nome" required />
            <input type="text" placeholder="Email/Telefone" required />

            <button type="button" className="btn-rosa">
              Usar dados de cadastro
            </button>
          </form>
        </div>

        <div className="resumo-section">
          <h2>
            Total da compra: <span className="valor">R$7,50</span>
          </h2>

          <button className="btn-rosa">Gerar QRCode</button>
          <p className="contato">Contato: (11)99902-8922</p>
        </div>
      </div>
    </>
  );
}
