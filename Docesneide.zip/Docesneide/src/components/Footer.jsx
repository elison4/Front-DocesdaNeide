import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-left">@docesdaneide</div>
      <div className="footer-right">Contato: (11)99902-8922</div>
    </footer>
  );
}

export default Footer;
