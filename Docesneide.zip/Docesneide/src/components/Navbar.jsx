import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import "./Navbar.css";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const goToSection = (id) => {
    setMenuOpen(false);

    if (location.pathname !== "/") {
      navigate(`/#${id}`);
    } else {
      scrollToSection(id);
    }
  };

  // Fecha menu ao mudar de rota
  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <nav className="navbar">
      <div className="logo">
        <span className="logo-black">Doces da</span>
        <span className="logo-pink">Neide</span>
      </div>

      {/* Botão hamburger */}
      <div
        className={`hamburger ${menuOpen ? "open" : ""}`}
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Menu"
        aria-expanded={menuOpen}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") setMenuOpen(!menuOpen);
        }}
      >
        <span></span>
        <span></span>
        <span></span>
      </div>

      <ul className={`nav-links ${menuOpen ? "open" : ""}`}>
        <li onClick={() => goToSection("doces")} style={{ cursor: "pointer" }}>
          Doces
        </li>
        <li
          onClick={() => goToSection("promocoes")}
          style={{ cursor: "pointer" }}
        >
          Promoções
        </li>
        <li
          onClick={() => goToSection("eventos")}
          style={{ cursor: "pointer" }}
        >
          Eventos
        </li>
        <li
          onClick={() => goToSection("encomendar")}
          className="btn-encomendar"
          style={{ cursor: "pointer" }}
        > Encomendar
        </li>
        <li>
          <Link to="/carrinho" onClick={() => setMenuOpen(false)}>
            Cestinha
          </Link>
        </li>
        
        


      </ul>
    </nav>
  );
}

export default Navbar;
